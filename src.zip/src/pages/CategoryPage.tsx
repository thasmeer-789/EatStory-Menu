
import { useNavigate, useParams } from "react-router-dom";
import { categories } from "../data/menuData";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const CategoryPage = () => {

  const navigate = useNavigate();

  const { title } = useParams();

  const [activeSection, setActiveSection] =
    useState("");

  const category = categories.find(
    (cat) =>
      cat.title.toLowerCase() === title
  );

  useEffect(() => {
  if (!category) return;

  setActiveSection(
    category.subCategories[0].title
  );
}, [category]);

  useEffect(() => {

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });

  }, [title]);

 useEffect(() => {

  if (!category) return;

  const handleScroll = () => {

    category.subCategories.forEach((sub) => {

      const element =
        document.getElementById(
          sub.title.replace(/\s+/g, "-")
        );

      if (element) {

        const rect =
          element.getBoundingClientRect();

        if (
          rect.top <= 140 &&
          rect.bottom >= 140
        ) {
          setActiveSection(sub.title);
        }
      }
    });
  };

  handleScroll();

  window.addEventListener(
    "scroll",
    handleScroll,
    { passive: true }
  );

  return () =>
    window.removeEventListener(
      "scroll",
      handleScroll
    );

}, [category]);
  if (!category) {
    return (
      <div className="h-screen flex items-center justify-center bg-primary text-cream">
        Category Not Found
      </div>
    );
  }

  return (

    <section className="relative min-h-screen bg-primary text-cream overflow-x-hidden">

      {/* Glow Top */}
      <motion.div
        animate={{
          x: [0, 40, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="
          absolute
          top-0
          left-0
          w-[220px]
          h-[220px]
          sm:w-[400px]
          sm:h-[400px]
          bg-accent/20
          blur-[120px]
          rounded-full
        "
      />

      {/* Glow Bottom */}
      <motion.div
        animate={{
          x: [0, -40, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 14,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="
          absolute
          bottom-0
          right-0
          w-[220px]
          h-[220px]
          sm:w-[400px]
          sm:h-[400px]
          bg-[#F5DAA7]/10
          blur-[120px]
          rounded-full
        "
      />

      <div className="relative z-10 max-w-6xl mx-auto">

        {/* HEADER */}
        <div className="relative z-40 backdrop-blur-2xl bg-primary/85 border-b border-white/10">

          <div className="w-full px-4 sm:px-6 py-4 sm:py-5">

            {/* TOP NAV */}
            <div
              className="
                      flex
                      items-center
                      justify-start
                      gap-2
                      sm:gap-3
                      overflow-x-auto
                      snap-x
                      snap-mandatory
                      scrollbar-hide
                      [-webkit-overflow-scrolling:touch]
                    "
            >

              {/* BACK */}
              <button
  aria-label="Back to home"
  onClick={() => navigate("/")}
                className="
                  snap-start
                  whitespace-nowrap
                  px-4
                  py-2
                  rounded-full
                  bg-accent
                  text-cream
                  text-sm
                  font-medium
                  transition-all
                  duration-300
"
              >
                ← Back
              </button>

              {/* MAIN CATEGORIES */}
              {categories.map((item) => (

                <button
                  key={item.id}
                  onClick={() =>
                    navigate(
                      `/category/${item.title.toLowerCase()}`
                    )
                  }
                  className={`
                    snap-start
                    whitespace-nowrap
                    px-4 sm:px-5
                    py-2
                    rounded-full
                    text-sm
                    transition-all
                    duration-300
                    ${
                      item.title === category.title
                        ? "bg-accent text-cream"
                        : "bg-white/10 text-cream/70"
                    }
                  `}
                >
                  {item.title}
                </button>

              ))}

            </div>

            {/* TITLE */}
           <h1
              className="
                text-center
                mt-8
                text-2xl
                sm:text-4xl
                md:text-5xl
                font-black
                tracking-[0.08em]
                sm:tracking-[0.15em]
                leading-tight
                text-[#F5DAA7]
                font-['Playfair_Display']
              "
            >
              {category.title}
            </h1>

          </div>

        </div>

{/* SUBCATEGORY NAV */}
<div
  className="
    sticky
    top-0
    z-[999]
    bg-primary
    border-y
    border-white/10
  "
>
  <div
    className="
      flex
      items-center
      gap-2
      sm:gap-3
      overflow-x-auto
      px-4
      sm:px-6
      py-3
      scrollbar-hide
      [-webkit-overflow-scrolling:touch]
    "
  >

    {category.subCategories.map((sub, index) => (

     <a
  key={index}
  href={`#${sub.title.replace(/\s+/g, "-")}`}
  aria-current={
    activeSection === sub.title
      ? "page"
      : undefined
  }
        className={`
          snap-start
          whitespace-nowrap
          px-3 sm:px-4
          py-2
          rounded-full
          text-sm
          transition-all
          duration-300
          ${
            activeSection === sub.title
              ? "bg-accent text-cream shadow-lg shadow-accent/30"
              : "bg-white/10 text-cream/70"
          }
        `}
      >
        {sub.title}
      </a>

    ))}

  </div>

</div>

        {/* MENU LIST */}
        <div className="relative z-10 w-full px-4 sm:px-5 pt-6 sm:pt-10 pb-24">
          {category.subCategories.map((sub, index) => (

            <motion.div
              key={index}
              id={sub.title.replace(/\s+/g, "-")}
             className="
                mb-16
                sm:mb-20
                scroll-mt-24
                sm:scroll-mt-28
              "
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >

              {/* SUBCATEGORY TITLE */}
              <h2
                className="
                  text-lg
                  sm:text-xl
                  font-semibold
                  tracking-[0.2em]
                  uppercase
                  text-center
                  text-[#F5DAA7]
                  mb-10
                  sm:mb-14
                "
              >
                {sub.title}
              </h2>

              {/* ITEMS */}
              <div className="space-y-4 sm:space-y-6">

                {sub.items.map((item, itemIndex) => (

                  <motion.div
                    key={itemIndex}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{
                          duration: 0.4,
                          delay: Math.min(
                            itemIndex * 0.04,
                            0.3
                          ),
                        }}
                    viewport={{ once: true }}
                    className="
                      group
                      flex
                      items-center
                      gap-2
                      sm:gap-3
                      py-4
                      sm:py-5
                      px-2
                      rounded-xl
                      hover:bg-white/5
                      transition-all
                      duration-300
                    "
                  >

                    {/* NAME */}
                    <h3
                        className="
                          text-sm
                          sm:text-base
                          font-medium
                          tracking-wide
                          text-cream
                          truncate
                          max-w-[60%]
                          group-hover:text-[#F5DAA7]
                          transition
                          font-['Inter']
                        "
                      >
                      {item.name}
                    </h3>

                    {/* LINE */}
                    <div
                      className="
                        flex-1
                        border-b
                        border-dashed
                        border-[#F5DAA7]/15
                        group-hover:border-[#F5DAA7]/40
                        transition
                      "
                    />

                    {/* PRICE */}
                    <span
                      className="
                        text-[#F5DAA7]
                        text-sm
                        sm:text-base
                        font-bold
                        tracking-wider
                        whitespace-nowrap
                        shrink-0
                        group-hover:scale-110
                        group-hover:text-white
                        transition
                      "
                    >
                      {item.price}
                    </span>

                  </motion.div>

                ))}

              </div>

            </motion.div>

          ))}

        </div>

      </div>

    </section>
  );
};

export default CategoryPage;